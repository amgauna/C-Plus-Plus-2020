main()
{
  char s[80];
  gets(s);
  lprintf("%s\n",s);
}
