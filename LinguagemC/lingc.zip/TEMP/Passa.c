main()
{
int x;
soma(&x)
printf("\nO valor digitado foi %d\n",x);
}

soma(z)
int *z;
{
int y;
printf("Digite um Valor: ");
scanf("%d",&y);
*z=y;
}
