main()
   {
     int i=1,j=2,k,l;
     i++;
     k=++i +k;
     l=j++ +l;
     ++j;
     printf("%d %d %d %d",i,j,k,l);
   }
