main()
{
 int a;
 printf("Digite um numero: ");
 scanf("%d",&a);
 printf("%d %c",a,a);
}
