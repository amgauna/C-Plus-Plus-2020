main()
{
 int y,a;
 printf("Digite um numero: ");
 scanf("%d",&a);
 printf("%d %u %c",a,a,a);
}
