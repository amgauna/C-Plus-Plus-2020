main()
{

int t[10],i;

puts("fjdjf");
for (i = 0 ; i < 10; ++i) 
   scanf("%d",&t[i]);
display(t);
}

display(num)
int *num;
{
  int i;
  for (i = 0, i < 10, i++) printf("%d\n",num[i]);
}
