main()
{
  char a,b,*p;
  b = 'c'; 
  p = &a;
  *p = b;
  printf("%c",a);
}
