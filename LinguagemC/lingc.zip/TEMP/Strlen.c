main()	/* strlen.c -- illustrates strlen(), string length function */

	{

	int length;
	char *string;

	string = "12345678984823467823847628";
	length = strlen(string);

	printf("Existem %d digitos no numero!\n", length);
	}
