int soma(int z);

main()
{
  int a,r,x;
  a = 10;
  x = 2 * a + 3;
  r = soma(a);
  printf("%d, %d e %d",a,x,r);
}

int soma(z)
int z;
{
  int x = 5;
  x = 2 * x + z;
  z = 0;
  return(x);
}
