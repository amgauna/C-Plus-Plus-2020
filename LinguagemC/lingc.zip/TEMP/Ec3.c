main()
{
  int *pc,*pd,c,d,e;
  printf("Digite um Numero: ");
  scanf("%d",&c);
  pc = &c;
  printf("c = %d ",*pc+4);
}
